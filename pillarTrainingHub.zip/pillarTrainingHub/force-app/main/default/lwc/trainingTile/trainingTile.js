import { LightningElement, api, track } from 'lwc';

export default class TrainingTile extends LightningElement {

    @api draggable;

    _training;

    @api
    get training() {
        return this._training;
    }
    set training(value) {
        this._training = value;
        this.pictureUrl = value.Picture_URL__c;
        this.name = value.Name;
    }

    @track pictureUrl;
    @track name;
    @track msrp;

    handleClick() {
        const selectedEvent = new CustomEvent('selected', {
            detail: this.training.Id
        });
        this.dispatchEvent(selectedEvent);
    }

    handleDragStart(event) {
        event.dataTransfer.setData('training', JSON.stringify(this.training));
    }
}
