import { LightningElement, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';

import { getRecord } from 'lightning/uiRecordApi';

import { registerListener, unregisterAllListeners } from 'c/pubsub';

import TRAINING_OBJECT from '@salesforce/schema/SigTraining__c';
import NAME_FIELD from '@salesforce/schema/SigTraining__c.Name';
import LEVEL_FIELD from '@salesforce/schema/SigTraining__c.Level__c';
import CATEGORY_FIELD from '@salesforce/schema/SigTraining__c.Category__c';
import DESCRIPTION_FIELD from '@salesforce/schema/SigTraining__c.Description__c';
import DOCUMENT_LINK_FIELD from '@salesforce/schema/SigTraining__c.Document_Link__c';
import VIDEO_LINK_FIELD from '@salesforce/schema/SigTraining__c.Video_Link__c';
import PICTURE_URL_FIELD from '@salesforce/schema/SigTraining__c.Picture_URL__c';


const fields = [
    NAME_FIELD,
    LEVEL_FIELD,
    CATEGORY_FIELD,
    DESCRIPTION_FIELD,
    DOCUMENT_LINK_FIELD,
    VIDEO_LINK_FIELD,
    PICTURE_URL_FIELD
];

export default class TrainingCard extends NavigationMixin(LightningElement) {
    recordId;

    @wire(CurrentPageReference) pageRef;

    @wire(getRecord, { recordId: '$recordId', fields })
    training;

    connectedCallback() {
        registerListener('trainingSelected', this.handleTrainingSelected, this);
    }

    disconnectedCallback() {
        unregisterAllListeners(this);
    }

    handleTrainingSelected(trainingId) {
        this.recordId = trainingId;
    }

    handleNavigateToRecord() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: TRAINING_OBJECT.objectApiName,
                actionName: 'view'
            }
        });
    }

    get noData() {
        return !this.training.error && !this.training.data;
    }
}
