import { LightningElement, api, track, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';

import getTrainings from '@salesforce/apex/TrainingController.getTrainings';

/** Pub-sub mechanism for sibling component communication. */
import { registerListener, unregisterAllListeners, fireEvent } from 'c/pubsub';

export default class TrainingTileList extends LightningElement {

    @api searchBarIsVisible = false;

    @api tilesAreDraggable = false;

    @track pageNumber = 1;

    @track pageSize;

    @track totalItemCount = 0;

    @track filters = {};

    @wire(CurrentPageReference) pageRef;

    @wire(getTrainings, { filters: '$filters', pageNumber: '$pageNumber' })
    trainings;

    connectedCallback() {
        registerListener('filterChange', this.handleFilterChange, this);
    }

    handleTrainingSelected(event) {
        fireEvent(this.pageRef, 'trainingSelected', event.detail);
    }

    disconnectedCallback() {
        unregisterAllListeners(this);
    }

    handleSearchKeyChange(event) {
        this.filters = {
            searchKey: event.target.value.toLowerCase()
        };
        this.pageNumber = 1;
    }

    handleFilterChange(filters) {
        this.filters = { ...filters };
        this.pageNumber = 1;
    }

    handlePreviousPage() {
        this.pageNumber = this.pageNumber - 1;
    }

    handleNextPage() {
        this.pageNumber = this.pageNumber + 1;
    }
}
