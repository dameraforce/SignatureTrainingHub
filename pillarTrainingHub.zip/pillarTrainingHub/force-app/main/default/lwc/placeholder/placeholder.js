import { LightningElement, api, track } from 'lwc';

import BIKE_ASSETS_URL from '@salesforce/resourceUrl/trainingResource';

export default class Placeholder extends LightningElement {
    @api message;

    @track logoUrl = BIKE_ASSETS_URL + '/logo.svg';
}
