declare module "@salesforce/resourceUrl/trainingResource" {
    var trainingResource: string;
    export default trainingResource;
}
